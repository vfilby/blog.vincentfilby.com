/* $Id: fileUtils.h,v 1.4 2001/04/06 09:49:56 amai Exp $ */
int ParseFilename(const char *fullname, char *filename, char *pathname);
int ExpandTilde(char *pathname);
