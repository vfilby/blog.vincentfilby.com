/* $Id: utils.h,v 1.2 2001/02/26 23:38:03 edg Exp $ */
#ifndef _UTILS_H
#define _UTILS_H

extern const char *GetCurrentDir(void);

extern const char *GetHomeDir(void);

#endif /* _UTILS_H */
