/* $Id: parse.h,v 1.4 2001/07/11 21:35:50 amai Exp $ */

Program *ParseMacro(char *expr, char **msg, char **stoppedAt);
